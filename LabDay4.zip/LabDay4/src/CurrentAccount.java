public class CurrentAccount extends Account {
	double OverDraftLimit;


	public  CurrentAccount(long accNum,double balance,Persons accHolder,double OverDraftLimit)
	{
		super(accNum,balance,accHolder);
		this.OverDraftLimit=OverDraftLimit;
	}

	public void withdraw(double m) throws OverDraftLimitExceeded
	{
		if(m>OverDraftLimit)
		{
			balance=balance-m;
		}
		else
		{
			throw new OverDraftLimitExceeded();
		}
	}

}