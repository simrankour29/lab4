public class PersonAccount {

	public static void main(String[] args) {
		double acno1=Math.random()*1000;
		double acno2=Math.random()*1000;
		Persons p1=new Persons();
		p1.setName("Smith");
		p1.setAge(22);
		Account smithAcc = new Account();
		smithAcc.setaccHolder(p1);
		smithAcc.setAccNum((long)acno1);
		smithAcc.setBalance(2000);

		Persons p2=new Persons();
		p2.setName("Kathy");
		p2.setAge(20);
		Account kathyAcc = new Account();
		kathyAcc.setaccHolder(p1);
		kathyAcc.setAccNum((long)acno2);
		kathyAcc.setBalance(3000);

		smithAcc.deposit(2000);
		System.out.println(p1);
		System.out.println(smithAcc);
		try
		{
			kathyAcc.withdraw(2000);
			System.out.println(p2);
			System.out.println(kathyAcc);
		} catch(BalanceNotSufficientException e)
		{
			e.printStackTrace();
		}
		catch(OverDraftLimitExceeded e)
		{
			e.printStackTrace();
		}






	}

}