enum Gender{
	Undefined,M,F;
}
public class PersonwithEnum 
{

	private String firstName;
	private String lastName;
	private Gender gender;
	private String Phonenumber;
	PersonwithEnum()
	{
		this.firstName="";
		this.lastName="";
		this.gender=Gender.Undefined;
		this.Phonenumber="";
	}
	PersonwithEnum(String first, String last,Gender g,String p)
	{
		this.firstName=first;
		this.lastName=last;
		this.gender=g;
		this.Phonenumber=p;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String fs) {
		firstName = fs;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String ls) {
		lastName = ls;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender c) {
		gender = c;
	}
	public  String getPhonenumber()
	{
		return Phonenumber;
	}
	public void setPhonenumber(String p)
	{
		Phonenumber=p;
	}


	public void display () {
		System.out.println("Personal Details");
		System.out.println("_________");
		System.out.println("First Name:" +firstName);
		System.out.println("Last Name:" + lastName);
		System.out.println("Gender:" + gender);
		System.out.println("Phonenumber: " + Phonenumber);
	}



}