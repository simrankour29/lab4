public class EmptyInputException extends Exception{
	public EmptyInputException(){
		super("ERROR: Spaces entered - try again.");
	}
	public EmptyInputException(String npr){
		super("ERROR: Spaces entered for " + npr + " - Please try again.");
	}
}